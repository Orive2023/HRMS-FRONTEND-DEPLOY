import React, { useEffect } from "react";

//import Search from "../../common/Search";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";

import DialogContent from "@mui/material/DialogContent";
// import DialogTitle from '@mui/material/DialogTitle';

import { MdAdd } from "react-icons/md";

import Header from "../../../../components/Header";
import SideBar from "../../../../components/SideBar";

import * as api from "../api"
import StateAward from "../StateAward";
import AwardTable from "../AwardTable";
import AwardForm from "../AwardForm";


const AwardsView = () => {

  const { setRecDelete,recDelete,award,setAward,open,setOpen,formData,setFormData } = StateAward();
 

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };


  useEffect(() => {
    loadAward();
  }, []);

  const loadAward = async () => {
    const result = await api.loadAward();
    setAward(result);
    console.log(result);
  };

  const handleDelete = async () => {
    await api.deleteAward(recDelete);
    loadAward()
  };

  useEffect(() => {
    if (recDelete !== "") {
      handleDelete();
      setRecDelete("");
    }
  });

  console.log(formData)

  return (
    <div>
      <Header />
      <div className="dashboard-container">
        <SideBar />
        <div className="head-foot-part" style={{ padding: "0" }}>
        <section>
            <div
              className="above-table"
              style={{ display: "flex", justifyContent: "space-between" }}
            >
              <div>
                <Button
                  variant="outlined"
                  onClick={handleOpen}
                  style={{ height: "35px" }}
                >
                  <MdAdd style={{ fontSize: "14px", marginRight: "3px" }} />
                  ADD AWARDS
                </Button>
              </div>
            </div>
            <AwardTable award={award} setRecDelete={setRecDelete}/>
            <div>
              <Dialog open={open} onClose={handleClose}>
                <h3 style={{ textAlign: "center", marginTop: "30px" }}>
                  AWARD FORM
                </h3>
                <DialogContent>
                 <AwardForm formData={formData} setFormData={setFormData} setOpen={setOpen}/>
                </DialogContent>
              </Dialog>
            </div>
          </section>
        </div>
      </div>
    </div>

  );
};

export default AwardsView;

